from setuptools import setup 

setup(name='probability_distributions',
      version='1.0',
      description='This pacakage contains probability distributions like Gaussian Distribution etc.',
      author='Ayush Rawat',
      author_email='ayush.rawat19@icloud.com',
      packages=['distributions'],
      zip_safe = False
     )